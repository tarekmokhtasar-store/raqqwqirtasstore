import { PHYSICAL_PRODUCTS } from "@/data/products";
import { STORE_SETTINGS } from "@/data/store-settings";
import { buildProductOrderMessage, buildWhatsAppLink } from "@/lib/whatsapp";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";

export function generateStaticParams() {
  return PHYSICAL_PRODUCTS.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const product = PHYSICAL_PRODUCTS.find((p) => p.slug === params.slug);
  if (!product) return { title: "المنتج غير موجود | رُقّ وقرطاس" };
  return {
    title: `${product.name} | ${STORE_SETTINGS.storeName}`,
    description: product.shortDescription,
    openGraph: {
      title: product.name,
      description: product.shortDescription,
      images: [product.mainImage],
    },
  };
}

export default function ProductDetailPage({ params }: { params: { slug: string } }) {
  const product = PHYSICAL_PRODUCTS.find((p) => p.slug === params.slug);
  if (!product) notFound();

  const waUrl = buildWhatsAppLink(
    buildProductOrderMessage(
      product,
      1,
      product.availableColors[0] || "قياسي",
      "القاهرة",
      "يُحدد في المحادثة",
      ""
    )
  );

  return (
    <main className="max-w-6xl mx-auto px-4 py-10">
      <div className="mb-6">
        <Link href="/" className="text-sm font-bold text-[#0B3B2E] hover:underline">
          ← العودة إلى متجر رُقّ وقرطاس
        </Link>
      </div>
      <div className="grid md:grid-cols-12 gap-8 bg-white p-6 md:p-10 rounded-3xl border border-[#EAE0D0] shadow-sm">
        <div className="md:col-span-5">
          <img
            src={product.mainImage}
            alt={product.name}
            className="w-full rounded-2xl shadow-lg border border-[#D4AF37]/30"
          />
        </div>
        <div className="md:col-span-7 space-y-5">
          <span className="px-3 py-1 rounded-full bg-[#0B3B2E]/10 text-[#0B3B2E] text-xs font-bold">
            {product.categoryName}
          </span>
          <h1 className="text-2xl md:text-3xl font-extrabold text-[#0B3B2E]">{product.name}</h1>
          <div className="p-3.5 rounded-xl bg-[#F5EFE6] border border-[#D4AF37]/40 text-sm font-bold text-[#0B3B2E]">
            السعر والتوفر: {product.priceDisplayLabel}
          </div>
          <p className="text-[#4A3525] leading-relaxed">{product.marketingDescription}</p>
          <div className="space-y-2 text-sm">
            <h3 className="font-bold text-[#0B3B2E]">المواصفات الفنية:</h3>
            <ul className="list-disc list-inside space-y-1 text-[#4A3525]">
              {product.specifications.map((s, i) => (
                <li key={i}>
                  <strong>{s.label}:</strong> {s.value}
                </li>
              ))}
            </ul>
          </div>
          <div className="pt-4">
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-6 py-3.5 rounded-xl bg-[#0B3B2E] text-[#FBF8F3] font-bold hover:bg-[#125241] transition"
            >
              اطلب المنتج الآن عبر واتساب
            </a>
          </div>
        </div>
      </div>
    </main>
  );
}
