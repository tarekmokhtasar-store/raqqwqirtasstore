import type { Metadata } from "next";
import "./globals.css";
import { STORE_SETTINGS } from "@/data/store-settings";

export const metadata: Metadata = {
  title: `${STORE_SETTINGS.storeName} | ${STORE_SETTINGS.heroHeadline}`,
  description: STORE_SETTINGS.heroDescription,
  keywords: [
    "رُقّ وقرطاس",
    "كتب رقمية إسلامية",
    "قصص الأنبياء للأطفال",
    "قصص الصحابة",
    "تعلم الصلاة والوضوء بالصور",
    "منتجات مختارة مصر",
    "هدايا إسلامية",
  ],
  openGraph: {
    title: `${STORE_SETTINGS.storeName} — دار الكتب الرقمية والمنتجات المختارة`,
    description: STORE_SETTINGS.heroDescription,
    locale: "ar_EG",
    type: "website",
    images: ["/assets/banners/hero-library.webp"],
  },
  icons: {
    icon: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className="min-h-screen bg-[#FBF8F3] text-[#1F1610] antialiased selection:bg-[#0B3B2E] selection:text-[#FBF8F3]">
        {children}
      </body>
    </html>
  );
}
