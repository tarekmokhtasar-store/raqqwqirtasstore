import { DIGITAL_BOOKS } from "@/data/books";
import { STORE_SETTINGS } from "@/data/store-settings";
import { buildBookOrderMessage, buildWhatsAppLink } from "@/lib/whatsapp";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";

export function generateStaticParams() {
  return DIGITAL_BOOKS.map((book) => ({ slug: book.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const book = DIGITAL_BOOKS.find((b) => b.slug === params.slug);
  if (!book) return { title: "الكتاب غير موجود | رُقّ وقرطاس" };
  return {
    title: `${book.title} | ${STORE_SETTINGS.storeName}`,
    description: book.shortDescription,
    openGraph: {
      title: book.title,
      description: book.shortDescription,
      images: [book.coverImage],
    },
  };
}

export default function BookDetailPage({ params }: { params: { slug: string } }) {
  const book = DIGITAL_BOOKS.find((b) => b.slug === params.slug);
  if (!book) notFound();

  const waUrl = buildWhatsAppLink(buildBookOrderMessage(book, 1));

  return (
    <main className="max-w-6xl mx-auto px-4 py-10">
      <div className="mb-6">
        <Link href="/" className="text-sm font-bold text-[#0B3B2E] hover:underline">
          ← العودة إلى متجر رُقّ وقرطاس
        </Link>
      </div>
      <div className="grid md:grid-cols-12 gap-8 bg-white p-6 md:p-10 rounded-3xl border border-[#EAE0D0] shadow-sm">
        <div className="md:col-span-5">
          <img
            src={book.coverImage}
            alt={book.title}
            className="w-full rounded-2xl shadow-lg border border-[#D4AF37]/30"
          />
        </div>
        <div className="md:col-span-7 space-y-5">
          <div className="flex flex-wrap gap-2">
            <span className="px-3 py-1 rounded-full bg-[#0B3B2E]/10 text-[#0B3B2E] text-xs font-bold">
              {book.categoryName}
            </span>
            <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold">
              {book.availabilityStatus}
            </span>
          </div>
          <h1 className="text-2xl md:text-4xl font-extrabold text-[#0B3B2E]">{book.title}</h1>
          <p className="text-[#8C6D32] font-semibold">{book.subtitle}</p>
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
            {book.demoNotice}
          </div>
          <div className="text-3xl font-extrabold text-[#0B3B2E]">
            {book.price} {STORE_SETTINGS.currencySymbol}
          </div>
          <p className="text-[#4A3525] leading-relaxed">{book.fullDescription}</p>
          <div className="p-4 rounded-xl bg-[#F5EFE6] border border-[#D4AF37]/30 text-sm text-[#0B3B2E]">
            <strong>شاهد شرعي موثق:</strong> {book.verifiedReligiousReference}
          </div>
          <div className="pt-4 flex flex-wrap gap-3">
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3.5 rounded-xl bg-[#0B3B2E] text-[#FBF8F3] font-bold hover:bg-[#125241] transition"
            >
              اطلب الكتاب الآن عبر واتساب
            </a>
          </div>
        </div>
      </div>
    </main>
  );
}
