import { POLICIES_CONTENT } from "@/data/policies";
import { STORE_SETTINGS } from "@/data/store-settings";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";

export function generateStaticParams() {
  return POLICIES_CONTENT.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const policy = POLICIES_CONTENT.find((p) => p.slug === params.slug);
  if (!policy) return { title: "السياسة غير موجودة | رُقّ وقرطاس" };
  return {
    title: `${policy.title} | ${STORE_SETTINGS.storeName}`,
    description: policy.subtitle,
  };
}

export default function PolicyPage({ params }: { params: { slug: string } }) {
  const policy = POLICIES_CONTENT.find((p) => p.slug === params.slug);
  if (!policy) notFound();

  return (
    <main className="max-w-4xl mx-auto px-4 py-10">
      <div className="mb-6">
        <Link href="/" className="text-sm font-bold text-[#0B3B2E] hover:underline">
          ← العودة إلى الصفحة الرئيسية
        </Link>
      </div>
      <article className="bg-white p-8 rounded-3xl border border-[#EAE0D0] shadow-sm space-y-6">
        <header className="border-b border-[#EAE0D0] pb-5">
          <h1 className="text-2xl md:text-3xl font-extrabold text-[#0B3B2E]">{policy.title}</h1>
          <p className="text-[#8C6D32] mt-1">{policy.subtitle}</p>
        </header>
        {policy.sections.map((sec, idx) => (
          <section key={idx} className="space-y-3">
            <h2 className="text-lg font-bold text-[#0B3B2E]">{sec.heading}</h2>
            {sec.paragraphs.map((p, i) => (
              <p key={i} className="text-[#4A3525] leading-relaxed">
                {p}
              </p>
            ))}
            {sec.bullets && (
              <ul className="list-disc list-inside space-y-1.5 text-[#4A3525]">
                {sec.bullets.map((b, j) => (
                  <li key={j}>{b}</li>
                ))}
              </ul>
            )}
          </section>
        ))}
      </article>
    </main>
  );
}
