import Link from "next/link";
import { BookOpen, Home } from "lucide-react";

export default function NotFound() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-[#FBF8F3] px-4 text-center">
      <div className="w-20 h-20 rounded-3xl bg-[#0B3B2E] text-[#D4AF37] flex items-center justify-center mb-6 shadow-lg">
        <BookOpen className="w-10 h-10" />
      </div>
      <span className="text-sm font-bold tracking-wider text-[#9A7B38] bg-[#F5EFE6] px-4 py-1.5 rounded-full border border-[#D4AF37]/40 mb-3">
        خطأ 404 — الصفحة غير موجودة
      </span>
      <h1 className="text-3xl md:text-4xl font-extrabold text-[#0B3B2E] mb-4">
        عذرًا، هذه الورقة ليست بين دفتي كتابنا!
      </h1>
      <p className="text-[#4A3525] max-w-md mb-8 leading-relaxed">
        يبدو أن الرابط الذي تبحث عنه قد تغير أو غير متاح حاليًا. يمكنك العودة إلى الصفحة الرئيسية لتصفح الكتب الرقمية والمنتجات المختارة.
      </p>
      <Link
        href="/"
        className="inline-flex items-center gap-2 bg-[#0B3B2E] hover:bg-[#125241] text-[#FBF8F3] font-bold px-6 py-3.5 rounded-xl shadow-md transition"
      >
        <Home className="w-5 h-5 text-[#D4AF37]" />
        <span>العودة إلى الصفحة الرئيسية</span>
      </Link>
    </main>
  );
}
