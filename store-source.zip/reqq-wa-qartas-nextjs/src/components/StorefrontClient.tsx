"use client";

import React, { useState, useEffect, useMemo } from "react";
import { STORE_SETTINGS } from "@/data/store-settings";
import { MAIN_SECTIONS, CATEGORIES, SubCategory } from "@/data/categories";
import { DIGITAL_BOOKS, DigitalBook } from "@/data/books";
import { PHYSICAL_PRODUCTS, PhysicalProduct } from "@/data/products";
import { BOOK_BUNDLE_OFFERS } from "@/data/offers";
import { POLICIES_CONTENT, FAQ_ITEMS } from "@/data/policies";
import {
  CartItem,
  buildWhatsAppLink,
  buildBookOrderMessage,
  buildProductOrderMessage,
  buildCartWhatsAppMessage,
} from "@/lib/whatsapp";
import {
  Search,
  ShoppingBag,
  Heart,
  BookOpen,
  Package,
  Sparkles,
  CheckCircle2,
  MessageCircle,
  Copy,
  Check,
  Trash2,
  Plus,
  Minus,
  ArrowUp,
  Menu,
  X,
  ShieldCheck,
  Truck,
  HelpCircle,
  Mail,
  Phone,
  Lock,
  Play,
  SlidersHorizontal,
  Gift,
  Compass,
  Droplets,
  ChevronLeft,
} from "lucide-react";

type ActiveView =
  | { type: "home" }
  | { type: "section"; sectionId: "adults-books" | "kids-books" | "learn-islam" | "physical-products"; subCategoryId?: string }
  | { type: "book-detail"; bookId: string }
  | { type: "product-detail"; productId: string }
  | { type: "build-library" }
  | { type: "cart" }
  | { type: "wishlist" }
  | { type: "policy"; slug: string }
  | { type: "faq" }
  | { type: "contact" }
  | { type: "admin-guide" };

export default function StorefrontClient() {
  const [view, setView] = useState<ActiveView>({ type: "home" });
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSubCat, setSelectedSubCat] = useState<string>("all");
  const [selectedStyleFilter, setSelectedStyleFilter] = useState<string>("all");
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);
  const [isVodafoneModalOpen, setIsVodafoneModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedWallet, setCopiedWallet] = useState(false);

  // Customer checkout & physical order fields
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerGovernorate, setCustomerGovernorate] = useState("القاهرة");
  const [customerAddress, setCustomerAddress] = useState("");
  const [transferRef, setTransferRef] = useState("");
  const [orderNotes, setOrderNotes] = useState("");
  const [agreedToDigitalPolicy, setAgreedToDigitalPolicy] = useState(false);

  // Custom library builder selection
  const [builderBookIds, setBuilderBookIds] = useState<string[]>(["bk-01", "bk-06", "bk-12"]);

  // Load persisted cart & wishlist safely
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem("reqq_cart_v1");
      if (savedCart) setCart(JSON.parse(savedCart));
      const savedWish = localStorage.getItem("reqq_wishlist_v1");
      if (savedWish) setWishlist(JSON.parse(savedWish));
    } catch {
      // Ignore storage block in restricted frames
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("reqq_cart_v1", JSON.stringify(cart));
    } catch {}
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem("reqq_wishlist_v1", JSON.stringify(wishlist));
    } catch {}
  }, [wishlist]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const addBookToCart = (book: DigitalBook, qty = 1) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === book.id && i.itemType === "book");
      if (existing) {
        return prev.map((i) =>
          i.id === book.id && i.itemType === "book" ? { ...i, quantity: i.quantity + qty } : i
        );
      }
      return [
        ...prev,
        {
          id: book.id,
          itemType: "book",
          title: book.title,
          price: book.price,
          quantity: qty,
          image: book.coverImage,
          slug: book.slug,
        },
      ];
    });
    showToast(`تمت إضافة «${book.title}» إلى سلة التسوق`);
  };

  const addProductToCart = (
    product: PhysicalProduct,
    qty = 1,
    color?: string,
    size?: string,
    option?: string
  ) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === product.id && i.itemType === "product");
      if (existing) {
        return prev.map((i) =>
          i.id === product.id && i.itemType === "product"
            ? { ...i, quantity: i.quantity + qty }
            : i
        );
      }
      return [
        ...prev,
        {
          id: product.id,
          itemType: "product",
          title: product.name,
          price: product.customerFinalPrice,
          quantity: qty,
          image: product.mainImage,
          slug: product.slug,
          selectedColor: color || product.availableColors[0],
          selectedSize: size || product.availableSizes[0],
          selectedOption: option || product.productOptions[0],
        },
      ];
    });
    showToast(`تمت إضافة «${product.name}» إلى سلة التسوق`);
  };

  const updateCartQty = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => (item.id === id ? { ...item, quantity: item.quantity + delta } : item))
        .filter((item) => item.quantity > 0)
    );
  };

  const removeFromCart = (id: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  const toggleWishlist = (id: string) => {
    setWishlist((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const totalItemsCount = useMemo(
    () => cart.reduce((acc, item) => acc + item.quantity, 0),
    [cart]
  );

  const booksInCartCount = useMemo(
    () =>
      cart
        .filter((i) => i.itemType === "book")
        .reduce((acc, item) => acc + item.quantity, 0),
    [cart]
  );

  const confirmedBooksTotal = useMemo(
    () =>
      cart
        .filter((i) => i.itemType === "book")
        .reduce((acc, item) => acc + (item.price || 0) * item.quantity, 0),
    [cart]
  );

  const copyWalletNumber = () => {
    const text = STORE_SETTINGS.vodafoneCashWallet;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(() => {});
    }
    setCopiedWallet(true);
    setTimeout(() => setCopiedWallet(false), 2500);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FBF8F3] text-[#1F1610]">
      {/* شريط إعلاني علوي للعروض */}
      <div className="bg-[#0B3B2E] text-[#FBF8F3] text-xs md:text-sm py-2.5 px-4 border-b border-[#D4AF37]/30">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 font-medium">
            <Sparkles className="w-4 h-4 text-[#D4AF37] shrink-0" />
            <span>{STORE_SETTINGS.bookBundleNotice}</span>
          </div>
          <div className="flex items-center gap-4 text-xs text-[#E8CF8C]">
            <button
              onClick={() => setView({ type: "build-library" })}
              className="underline hover:text-white transition"
            >
              كوّن مكتبتك الآن
            </button>
            <span>•</span>
            <a
              href={buildWhatsAppLink("السلام عليكم، أود الاستفسار عن متجر رُقّ وقرطاس.")}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition"
            >
              واتساب الطلبات: {STORE_SETTINGS.whatsappLocal}
            </a>
          </div>
        </div>
      </div>

      {/* Header احترافي */}
      <header className="sticky top-0 z-40 bg-[#FBF8F3]/95 backdrop-blur-md border-b border-[#EAE0D0] shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <button
            onClick={() => setView({ type: "home" })}
            className="flex items-center gap-3 text-right group"
          >
            <img
              src="/assets/brand/logo-icon.svg"
              alt="شعار رُقّ وقرطاس"
              className="w-12 h-12 rounded-xl shadow-sm"
            />
            <div>
              <span className="block text-xl md:text-2xl font-extrabold text-[#0B3B2E] group-hover:text-[#125241] transition">
                {STORE_SETTINGS.storeName}
              </span>
              <span className="block text-xs text-[#8C6D32] font-medium">
                {STORE_SETTINGS.tagline}
              </span>
            </div>
          </button>

          {/* شريط البحث السريع */}
          <div className="hidden md:flex flex-1 max-w-md relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن كتاب أو قصة أو منتج..."
              className="w-full rounded-xl bg-[#F5EFE6] border border-[#D8C8B0] px-4 py-2.5 pr-10 text-sm focus:outline-none focus:border-[#0B3B2E]"
            />
            <Search className="w-4 h-4 text-[#6B4F38] absolute right-3.5 top-3" />
          </div>

          {/* أزرار الهيدر */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setView({ type: "wishlist" })}
              className="relative p-2.5 rounded-xl bg-[#F5EFE6] hover:bg-[#EAE0D0] text-[#0B3B2E] transition"
              title="المفضلة"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -left-1 w-5 h-5 rounded-full bg-[#C5A059] text-white text-xs font-bold flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setIsCartDrawerOpen(true)}
              className="relative flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-[#0B3B2E] hover:bg-[#125241] text-[#FBF8F3] font-bold text-sm transition shadow-sm"
            >
              <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
              <span className="hidden sm:inline">السلة</span>
              <span className="px-2 py-0.5 rounded-full bg-[#D4AF37] text-[#0B3B2E] text-xs font-extrabold">
                {totalItemsCount}
              </span>
            </button>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2.5 rounded-xl bg-[#F5EFE6] text-[#0B3B2E]"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* شريط التنقل بين الأقسام */}
        <nav className="max-w-7xl mx-auto px-4 py-2 border-t border-[#EAE0D0]/70 flex items-center gap-2 overflow-x-auto text-xs md:text-sm font-bold text-[#2C1E14]">
          <button
            onClick={() => setView({ type: "home" })}
            className="px-3 py-1.5 rounded-lg hover:bg-[#F5EFE6] shrink-0"
          >
            الرئيسية
          </button>
          <button
            onClick={() => {
              setSelectedSubCat("all");
              setView({ type: "section", sectionId: "adults-books" });
            }}
            className="px-3 py-1.5 rounded-lg hover:bg-[#F5EFE6] shrink-0"
          >
            كتب الكبار (18 قسمًا)
          </button>
          <button
            onClick={() => {
              setSelectedSubCat("all");
              setView({ type: "section", sectionId: "kids-books" });
            }}
            className="px-3 py-1.5 rounded-lg hover:bg-[#F5EFE6] shrink-0"
          >
            كتب الأطفال (16 قسمًا)
          </button>
          <button
            onClick={() => {
              setSelectedSubCat("all");
              setView({ type: "section", sectionId: "learn-islam" });
            }}
            className="px-3 py-1.5 rounded-lg bg-[#0B3B2E]/10 text-[#0B3B2E] hover:bg-[#0B3B2E]/20 shrink-0"
          >
            تعلم الإسلام بالصور
          </button>
          <button
            onClick={() => {
              setSelectedSubCat("all");
              setView({ type: "section", sectionId: "physical-products" });
            }}
            className="px-3 py-1.5 rounded-lg hover:bg-[#F5EFE6] shrink-0"
          >
            المنتجات المادية المختارة
          </button>
          <button
            onClick={() => setView({ type: "build-library" })}
            className="px-3 py-1.5 rounded-lg text-[#8C6D32] hover:bg-[#F5EFE6] shrink-0"
          >
            كوّن مكتبتك
          </button>
          <button
            onClick={() => setView({ type: "policy", slug: "how-to-order" })}
            className="px-3 py-1.5 rounded-lg hover:bg-[#F5EFE6] shrink-0"
          >
            طريقة الطلب
          </button>
          <button
            onClick={() => setView({ type: "faq" })}
            className="px-3 py-1.5 rounded-lg hover:bg-[#F5EFE6] shrink-0"
          >
            الأسئلة الشائعة
          </button>
        </nav>
      </header>

      {/* محتوى المتجر المتغير */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
        {view.type === "home" && (
          <div className="space-y-12">
            {/* Hero Section */}
            <section className="relative rounded-3xl overflow-hidden bg-[#0B3B2E] text-[#FBF8F3] shadow-xl border border-[#D4AF37]/30">
              <div className="grid lg:grid-cols-2 items-center">
                <div className="p-8 md:p-12 space-y-6">
                  <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/50 text-[#E8CF8C] text-xs font-bold">
                    <Sparkles className="w-4 h-4" />
                    علامة تجارية عربية للكتب الرقمية والمنتجات المختارة
                  </span>
                  <h1 className="text-3xl md:text-5xl font-extrabold leading-tight">
                    {STORE_SETTINGS.heroHeadline}
                  </h1>
                  <p className="text-[#EAE0D0] text-base md:text-lg leading-relaxed">
                    {STORE_SETTINGS.heroDescription}
                  </p>
                  <div className="flex flex-wrap gap-4 pt-2">
                    <button
                      onClick={() =>
                        setView({ type: "section", sectionId: "adults-books" })
                      }
                      className="px-6 py-3.5 rounded-xl bg-[#D4AF37] hover:bg-[#C5A059] text-[#0B3B2E] font-extrabold text-sm md:text-base shadow-md transition"
                    >
                      اكتشف الكتب الرقمية
                    </button>
                    <button
                      onClick={() =>
                        setView({ type: "section", sectionId: "physical-products" })
                      }
                      className="px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-[#FBF8F3] border border-[#D4AF37]/40 font-bold text-sm md:text-base transition"
                    >
                      تسوق المنتجات المختارة
                    </button>
                  </div>
                </div>
                <div className="h-full min-h-[300px] lg:min-h-[440px] relative">
                  <img
                    src="/assets/banners/hero-library.webp"
                    alt="مكتبة رُقّ وقرطاس"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </section>
          </div>
        )}
      </main>

      {/* زر واتساب عائم احترافي في جميع الصفحات */}
      <a
        href={buildWhatsAppLink("السلام عليكم، أود الاستفسار والطلب من متجر رُقّ وقرطاس.")}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-5 left-5 z-50 flex items-center gap-2 bg-[#128C7E] hover:bg-[#075E54] text-white font-bold px-4 py-3 rounded-full shadow-xl transition"
      >
        <MessageCircle className="w-5 h-5" />
        <span className="text-xs md:text-sm">تواصل عبر واتساب</span>
      </a>
    </div>
  );
}
