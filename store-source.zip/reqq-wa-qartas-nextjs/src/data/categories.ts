export interface SubCategory {
  id: string;
  slug: string;
  name: string;
  parentGroup: "adults-books" | "kids-books" | "learn-islam" | "physical-products";
  description: string;
  iconName: string;
  badge?: string;
  isAdult18Plus?: boolean;
}

export interface MainSection {
  id: "adults-books" | "kids-books" | "learn-islam" | "physical-products";
  name: string;
  subtitle: string;
  bannerImage: string;
  description: string;
}

export const MAIN_SECTIONS: MainSection[] = [
  {
    id: "adults-books",
    name: "قسم كتب الكبار",
    subtitle: "تأصيل علمي، تزكية للنفوس، وسير خالدة",
    bannerImage: "/assets/banners/hero-library.webp",
    description:
      "مكتبة رقمية شاملة تضم السيرة النبوية، قصص الأنبياء والصحابة، فقه العبادات، العقيدة، تزكية النفس، وبناء الأسرة المسلمة.",
  },
  {
    id: "kids-books",
    name: "قسم كتب الأطفال",
    subtitle: "قصص مصورة وأنشطة تربوية تغرس الإيمان والفضيلة",
    bannerImage: "/assets/banners/kids-corner.webp",
    description:
      "إصدارات تربوية مصورة تناسب مختلف المراحل العمرية للطفل المسلم، من قصص الأنبياء والصحابة إلى تعليم الصلاة والوضوء والآداب اليومية.",
  },
  {
    id: "learn-islam",
    name: "قسم تعليم الإسلام",
    subtitle: "دليل تطبيقي مصور خطوة بخطوة للعبادات والعقيدة",
    bannerImage: "/assets/banners/learn-islam.webp",
    description:
      "منهج تعليمي مبسط وموثق بالأدلة الصحيحة لتعليم الوضوء والصلاة والطهارة والأذكار اليومية وأركان الإسلام والإيمان للكبار والناشئة.",
  },
  {
    id: "physical-products",
    name: "المنتجات المختارة (منصة تاجر مصر)",
    subtitle: "مستلزمات القراءة والمكتب والهدايا والأسرة بنظام الدروبشيبينج",
    bannerImage: "/assets/banners/products-flatlay.webp",
    description:
      "تشكيلة مختارة من المنتجات العملية والهدايا والأدوات المكتبية والتعليمية المتوفرة عبر منصة تاجر مصر مع توصيل لجميع المحافظات.",
  },
];

export const CATEGORIES: SubCategory[] = [
  // أولاً: قسم كتب الكبار (18 تصنيفًا)
  { id: "ab-general", slug: "islamic-general", name: "كتب إسلامية عامة", parentGroup: "adults-books", description: "مداخل معرفية شاملة للثقافة الإسلامية الوسطية.", iconName: "BookOpen" },
  { id: "ab-sahaba", slug: "sahaba-stories", name: "قصص الصحابة", parentGroup: "adults-books", description: "سير ومواقف أصحاب النبي ﷺ في البذل واليقين.", iconName: "Award" },
  { id: "ab-sahabiyat", slug: "sahabiyat-stories", name: "قصص الصحابيات", parentGroup: "adults-books", description: "قدوات مؤمنات من أمهات المؤمنين والصحابيات الجليلات.", iconName: "Heart" },
  { id: "ab-prophets", slug: "prophets-stories", name: "قصص الأنبياء", parentGroup: "adults-books", description: "مسيرة الوحي ودعوة الأنبياء والمرسلين في القرآن الكريم.", iconName: "Compass" },
  { id: "ab-seerah", slug: "prophetic-seerah", name: "السيرة النبوية", parentGroup: "adults-books", description: "دراسة موثقة لحياة النبي ﷺ في العهدين المكي والمدني.", iconName: "Sun" },
  { id: "ab-history", slug: "islamic-history", name: "قصص من التاريخ الإسلامي", parentGroup: "adults-books", description: "محطات مضيئة وحواضر علمية من تاريخ الحضارة الإسلامية.", iconName: "Landmark" },
  { id: "ab-tazkiyah", slug: "self-purification", name: "تزكية النفس", parentGroup: "adults-books", description: "إصلاح القلوب ومعالجة أمراض النفس ومقامات الإحسان.", iconName: "Sparkles" },
  { id: "ab-akhlaq", slug: "morals-etiquette", name: "الأخلاق والآداب", parentGroup: "adults-books", description: "حلية المسلم في معاملاته وآدابه اليومية.", iconName: "ShieldCheck" },
  { id: "ab-tarbiyah", slug: "islamic-education", name: "التربية الإسلامية", parentGroup: "adults-books", description: "أصول البناء التربوي والإيماني للفرد والمجتمع.", iconName: "GraduationCap" },
  { id: "ab-fiqh", slug: "fiqh-worship", name: "فقه العبادات", parentGroup: "adults-books", description: "أحكام الطهارة والصلاة والزكاة والصيام والحج بأسلوب ميسر.", iconName: "Scale" },
  { id: "ab-aqeedah", slug: "aqeedah-beginners", name: "العقيدة للمبتدئين", parentGroup: "adults-books", description: "تأصيل مبسط لأركان الإيمان والتوحيد الصافي.", iconName: "Anchor" },
  { id: "ab-adhkar", slug: "adhkar-supplications", name: "أذكار وأدعية", parentGroup: "adults-books", description: "الأذكار النبوية الصحيحة وأدعية القرآن والسنة.", iconName: "Moon" },
  { id: "ab-family", slug: "family-books", name: "كتب الأسرة", parentGroup: "adults-books", description: "بناء البيت المسلم وتحقيق المودة والسكينة الأسرية.", iconName: "Home" },
  { id: "ab-parenting", slug: "raising-children", name: "كتب تربية الأبناء", parentGroup: "adults-books", description: "أساليب عملية لتربية الأبناء على الفطرة في العصر الحديث.", iconName: "Users" },
  { id: "ab-tadabbur", slug: "contemplation-tadabbur", name: "كتب التفكر والتدبر", parentGroup: "adults-books", description: "مفاتيح تدبر القرآن الكريم والتفكر في آيات الآفاق والأنفس.", iconName: "Eye" },
  { id: "ab-selfdev", slug: "islamic-self-development", name: "كتب تطوير الذات من منظور إسلامي", parentGroup: "adults-books", description: "إدارة الوقت والهمة العالية والتوازن الحياتي برؤية شرعية.", iconName: "TrendingUp" },
  { id: "ab-faith", slug: "faith-books", name: "كتب إيمانية", parentGroup: "adults-books", description: "رقائق إيمانية تجدد اليقين وتبعث الأمل والسكينة.", iconName: "Flame" },
  {
    id: "ab-adults-18",
    slug: "adults-marital-fiqh-18",
    name: "قسم كتب +18 للبالغين (تأهيل أسري وزواجي نافع)",
    parentGroup: "adults-books",
    description: "مؤلفات شرعية وتربوية رصينة للمقبلين على الزواج والمتزوجين في فقه العشرة الزوجية وأحكام الأسرة الخاصة بضوابط العلم الشرعي.",
    iconName: "Lock",
    badge: "+18 محتوى علمي للمتزوجين",
    isAdult18Plus: true,
  },

  // ثانياً: قسم الأطفال (16 تصنيفًا)
  { id: "kb-prophets", slug: "kids-prophets-stories", name: "قصص الأنبياء للأطفال", parentGroup: "kids-books", description: "قصص الأنبياء بأسلوب مشوق ورسوم محببة للصغار.", iconName: "Star" },
  { id: "kb-sahaba", slug: "kids-sahaba-stories", name: "قصص الصحابة للأطفال", parentGroup: "kids-books", description: "بطولات وأخلاق الصحابة الكرام مبسطة للناشئة.", iconName: "Shield" },
  { id: "kb-bedtime", slug: "bedtime-stories", name: "قصص قبل النوم", parentGroup: "kids-books", description: "حكايات هادئة تختم يوم الطفل بقيمة تربوية وذكر نبوي.", iconName: "Moon" },
  { id: "kb-salah", slug: "kids-salah-stories", name: "قصص تعليم الصلاة", parentGroup: "kids-books", description: "تحبيب الصلاة للأطفال وشرح حركاتها وأوقاتها بالقصة.", iconName: "HeartHandshake" },
  { id: "kb-wudu", slug: "kids-wudu-stories", name: "قصص تعليم الوضوء", parentGroup: "kids-books", description: "رحلة مصورة لتعليم الطفل خطوات الوضوء والنظافة.", iconName: "Droplets" },
  { id: "kb-morals", slug: "kids-morals-stories", name: "قصص الأخلاق", parentGroup: "kids-books", description: "غرس الكرم والرحمة والتسامح وحسن الخلق.", iconName: "Smile" },
  { id: "kb-honesty", slug: "honesty-trustworthiness", name: "الصدق والأمانة", parentGroup: "kids-books", description: "مواقف قصصية تبرز جمال الصدق وحفظ الأمانة.", iconName: "CheckCircle" },
  { id: "kb-parents", slug: "honoring-parents", name: "بر الوالدين", parentGroup: "kids-books", description: "قصص تزرع محبة الوالدين وطاعتهما والإحسان إليهما.", iconName: "Heart" },
  { id: "kb-cooperation", slug: "cooperation-stories", name: "قصص عن التعاون", parentGroup: "kids-books", description: "تعزيز روح العمل الجماعي ومساعدة الآخرين.", iconName: "Users" },
  { id: "kb-educational", slug: "educational-stories", name: "قصص تربوية", parentGroup: "kids-books", description: "معالجة السلوكيات اليومية للأطفال بطريقة غير مباشرة.", iconName: "BookMarked" },
  { id: "kb-quran", slug: "kids-quran-stories", name: "قصص تعليم القرآن", parentGroup: "kids-books", description: "تقريب معاني قصار السور وآياتها لقلب الطفل.", iconName: "BookOpen" },
  { id: "kb-ramadan", slug: "ramadan-stories", name: "قصص رمضان", parentGroup: "kids-books", description: "يوميات الصوم وأجواء الشهر الفضيل للصغار.", iconName: "Sparkles" },
  { id: "kb-illustrated", slug: "illustrated-stories", name: "قصص مصورة", parentGroup: "kids-books", description: "كتب غنية باللوحات الفنية المناسبة للقارئ المبتدئ.", iconName: "Image" },
  { id: "kb-coloring", slug: "islamic-coloring-books", name: "كتب التلوين الإسلامية", parentGroup: "kids-books", description: "دفاتر تلوين قابلة للطباعة تنمي المهارات الفنية والقيم.", iconName: "Palette" },
  { id: "kb-activities", slug: "educational-activities", name: "أنشطة تعليمية", parentGroup: "kids-books", description: "تمارين ذكاء وألغاز وبطاقات تفاعلية هادفة.", iconName: "Puzzle" },
  { id: "kb-adventures", slug: "educational-adventures", name: "مغامرات تربوية", parentGroup: "kids-books", description: "رحلات استكشافية ممتعة للفتيان والفتيات.", iconName: "Map" },

  // ثالثاً: قسم تعليم الإسلام (15 تصنيفًا شاملاً الإضافات المقترحة)
  { id: "li-wudu-steps", slug: "learn-wudu-illustrated", name: "تعلم الوضوء بالصور خطوة بخطوة", parentGroup: "learn-islam", description: "شرح عملي مصور لفرائض وسنن الوضوء ونواقضه.", iconName: "Droplets", badge: "مصور خطوة بخطوة" },
  { id: "li-salah-steps", slug: "learn-salah-illustrated", name: "تعلم الصلاة بالصور", parentGroup: "learn-islam", description: "بيان صفة الصلاة الصحيحة من التكبير إلى التسليم بالصور.", iconName: "Compass", badge: "الأكثر طلبًا" },
  { id: "li-tahara", slug: "learn-tahara", name: "تعليم الطهارة", parentGroup: "learn-islam", description: "أحكام الطهارة والغسل والتيمم وآداب النظافة في الإسلام.", iconName: "Sparkles" },
  { id: "li-daily-adhkar", slug: "learn-daily-adhkar", name: "تعليم الأذكار اليومية", parentGroup: "learn-islam", description: "أذكار الصباح والمساء والنوم والصلاة مع شرح معانيها.", iconName: "Sun" },
  { id: "li-dua", slug: "learn-dua", name: "تعليم الدعاء", parentGroup: "learn-islam", description: "آداب الدعاء وأوقات الإجابة وجوامع الدعاء النبوي.", iconName: "Heart" },
  { id: "li-islam-pillars", slug: "pillars-of-islam", name: "أركان الإسلام", parentGroup: "learn-islam", description: "شرح مفصل وميسر لأركان الإسلام الخمسة ومقاصدها.", iconName: "Columns" },
  { id: "li-iman-pillars", slug: "pillars-of-iman", name: "أركان الإيمان", parentGroup: "learn-islam", description: "تأصيل أركان الإيمان الستة بلغة واضحة ومؤثرة.", iconName: "ShieldCheck" },
  { id: "li-fasting", slug: "learn-fasting", name: "تعليم الصيام", parentGroup: "learn-islam", description: "فقه الصيام وآدابه ومفسداته وسننه في رمضان وغيره.", iconName: "Moon" },
  { id: "li-hajj", slug: "learn-hajj-umrah", name: "تعليم الحج والعمرة", parentGroup: "learn-islam", description: "دليل خطوة بخطوة لمناسك الحج والعمرة وأدعيتهما.", iconName: "MapPin" },
  { id: "li-seerah-edu", slug: "learn-seerah", name: "تعليم السيرة النبوية", parentGroup: "learn-islam", description: "محطات السيرة النبوية مرتبة زمنيًا مع الدروس المستفادة.", iconName: "BookOpen" },
  { id: "li-aqeedah-basics", slug: "learn-aqeedah-basics", name: "أساسيات العقيدة", parentGroup: "learn-islam", description: "ما لا يسع المسلم جهله في التوحيد والاعتقاد الصحيح.", iconName: "Anchor" },
  { id: "li-daily-etiquette", slug: "daily-muslim-etiquette", name: "الآداب اليومية للمسلم", parentGroup: "learn-islam", description: "آداب الطعام والشراب واللباس والاستئذان والمجلس.", iconName: "Smile" },
  { id: "li-kids-salah", slug: "teach-kids-salah", name: "تعليم الأطفال الصلاة", parentGroup: "learn-islam", description: "منهج متدرج للوالدين والمربين لتدريب الطفل على الصلاة.", iconName: "Users" },
  { id: "li-short-surahs", slug: "tafsir-short-surahs", name: "تفسير قصار السور للمبتدئين (تصنيف مقترح)", parentGroup: "learn-islam", description: "فهم معاني سور جزء عمّ لتعزيز الخشوع في الصلاة.", iconName: "BookMarked", badge: "إضافة مقترحة" },
  { id: "li-daily-transactions", slug: "daily-fiqh-transactions", name: "فقه المعاملات اليومية الميسر (تصنيف مقترح)", parentGroup: "learn-islam", description: "ضوابط البيع والشراء والأمانات المالية في حياة المسلم.", iconName: "Scale", badge: "إضافة مقترحة" },

  // رابعاً: قسم المنتجات المادية من منصة تاجر (16 فئة)
  { id: "pp-tablets", slug: "tablets-drawing-pads", name: "التابلت وألواح الكتابة الرقمية", parentGroup: "physical-products", description: "ألواح كتابة ورسم إلكترونية LCD وتابلت تعليمي ومكتبي.", iconName: "Tablet" },
  { id: "pp-lighting", slug: "lighting-lamps", name: "الإضاءة والأضواء", parentGroup: "physical-products", description: "مصابيح قراءة مكتبية، إضاءات ليلية دافئة، وأباجورات ديكورية.", iconName: "Lamp" },
  { id: "pp-mugs", slug: "mugs-cups", name: "المجات والأكواب", parentGroup: "physical-products", description: "مجات سيراميك وأكواب حرارية حافظة للحرارة لركن القراءة.", iconName: "Coffee" },
  { id: "pp-stationery", slug: "stationery-supplies", name: "الأدوات المكتبية", parentGroup: "physical-products", description: "دفاتر تدوين فاخرة، أقلام، وفواصل كتب معدنية وخشبية.", iconName: "PenTool" },
  { id: "pp-heritage", slug: "heritage-products", name: "المنتجات التراثية", parentGroup: "physical-products", description: "مباخر، حوامل مصاحف وكتب خشبية، وقطع ديكور بطابع عربي أصيل.", iconName: "Sparkles" },
  { id: "pp-gifts", slug: "curated-gifts", name: "الهدايا", parentGroup: "physical-products", description: "بوكسات هدايا متكاملة للمناسبات الإسلامية والنجاح.", iconName: "Gift" },
  { id: "pp-educational", slug: "educational-tools", name: "الأدوات التعليمية", parentGroup: "physical-products", description: "وسائل تعليمية، بازل خشبي، وبطاقات تفاعلية لتنمية مهارات الطفل.", iconName: "Puzzle" },
  { id: "pp-accessories", slug: "accessories", name: "الإكسسوارات", parentGroup: "physical-products", description: "سبح طبيعية، حوامل هاتف وتابلت، وإكسسوارات شخصية أنيقة.", iconName: "Watch" },
  { id: "pp-tech", slug: "tech-products", name: "المنتجات التقنية", parentGroup: "physical-products", description: "سماعات، شواحن، وملحقات تقنية عملية للدراسة والعمل.", iconName: "Cpu" },
  { id: "pp-home", slug: "home-essentials", name: "مستلزمات المنزل", parentGroup: "physical-products", description: "منظمات منزلية وديكورات تضفي السكينة والترتيب على البيت.", iconName: "Home" },
  { id: "pp-practical", slug: "practical-products", name: "المنتجات العملية", parentGroup: "physical-products", description: "أدوات ذكية تسهل المهام اليومية في المكتب والمنزل.", iconName: "Wrench" },
  { id: "pp-desk-org", slug: "desk-organization", name: "منتجات تنظيم المكتب", parentGroup: "physical-products", description: "منظمات خشبية ومعدنية للأقلام والكتب والأوراق.", iconName: "FolderKanban" },
  { id: "pp-gift-ideas", slug: "gift-ready-items", name: "منتجات تصلح كهدايا", parentGroup: "physical-products", description: "اختيارات راقية بتغليف أنيق جاهزة للإهداء.", iconName: "Heart" },
  { id: "pp-kids-family", slug: "kids-family-products", name: "منتجات مناسبة للأطفال والأسرة", parentGroup: "physical-products", description: "ألعاب تنمية المهارات ومستلزمات آمنة ومفيدة للأسرة.", iconName: "Users" },
  { id: "pp-bookstands", slug: "wooden-bookstands", name: "حوامل المصاحف والكتب (إضافة مقترحة)", parentGroup: "physical-products", description: "حوامل خشبية مريحة للقراءة الطويلة وحفظ المصحف.", iconName: "BookOpen", badge: "إضافة مقترحة" },
  { id: "pp-reading-corner", slug: "reading-corner-essentials", name: "تجهيزات ركن القراءة (إضافة مقترحة)", parentGroup: "physical-products", description: "كل ما يحتاجه القارئ من إضاءة ودفتر تدوين ومج قهوة.", iconName: "Bookmark", badge: "إضافة مقترحة" },
];
