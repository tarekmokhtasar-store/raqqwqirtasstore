export interface StoreSettings {
  storeName: string;
  tagline: string;
  heroHeadline: string;
  heroDescription: string;
  email: string;
  whatsappLocal: string;
  whatsappIntl: string;
  whatsappUrl: string;
  country: string;
  currencyCode: string;
  currencySymbol: string;
  paymentMethodName: string;
  vodafoneCashWallet: string;
  vodafoneCashConfigured: boolean;
  bookBundleNotice: string;
  bookBundleRuleActive: boolean;
  bookBundleDiscountPercent: number;
  egyptGovConsumerLawUrl: string;
  governorates: string[];
}

export const STORE_SETTINGS: StoreSettings = {
  storeName: "رُقّ وقرطاس",
  tagline: "دار الكتب الرقمية الإسلامية والمنتجات المختارة",
  heroHeadline: "رُقّ وقرطاس.. لأن المعرفة تستحق أن تُحفظ بين دفتي كتاب",
  heroDescription:
    "منصة عربية تجمع بين أصالة الكتب الرقمية الإسلامية والتربوية للكبار والصغار، وتشكيلة مختارة بعناية من المنتجات العملية والهدايا ومستلزمات المكتب والأسرة في مصر.",
  email: "reqqwaqartas@gmail.com",
  whatsappLocal: "01275097757",
  whatsappIntl: "201275097757",
  whatsappUrl: "https://wa.me/201275097757",
  country: "مصر",
  currencyCode: "EGP",
  currencySymbol: "ج.م",
  paymentMethodName: "فودافون كاش (Vodafone Cash)",
  // هام لصاحب المتجر: استبدل القيمة التالية برقم محفظة فودافون كاش الحقيقي الخاص بك.
  // لا نفترض أن رقم واتساب الطلبات هو نفسه رقم المحفظة.
  vodafoneCashWallet:
    process.env.NEXT_PUBLIC_VODAFONE_CASH_WALLET || "01067901540",
  vodafoneCashConfigured: true,
  bookBundleNotice:
    "كلما زادت معرفتك، أصبح عرضك أجمل! اسألنا عن عروض مجموعات الكتب.",
  // لا يتم تطبيق خصم تلقائي إلا إذا قام صاحب المتجر بتفعيل هذا الخيار وتحديد النسبة
  bookBundleRuleActive: false,
  bookBundleDiscountPercent: 0,
  egyptGovConsumerLawUrl:
    "https://cpa.gov.eg/ar-EG/%D8%A7%D8%B3%D8%A6%D9%84%D8%A9-%D9%85%D8%AA%D9%83%D8%B1%D8%B1%D8%A9",
  governorates: [
    "القاهرة",
    "الجيزة",
    "الإسكندرية",
    "القليوبية",
    "الدقهلية",
    "الشرقية",
    "الغربية",
    "المنوفية",
    "البحيرة",
    "كفر الشيخ",
    "دمياط",
    "بورسعيد",
    "الإسماعيلية",
    "السويس",
    "بني سويف",
    "الفيوم",
    "المنيا",
    "أسيوط",
    "سوهاج",
    "قنا",
    "الأقصر",
    "أسوان",
    "البحر الأحمر",
    "مطروح",
    "الليوان / الوادي الجديد",
    "شمال سيناء",
    "جنوب سيناء",
  ],
};
