export interface DigitalBook {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  // تنبيه شفافية صارم: لا ننسب تأليفات وهمية لصاحب المتجر؛ هذا الحقل يوضح أنه نموذج عرض قابل للاستبدال
  authorLabel: string;
  isDemoSample: boolean;
  demoNotice: string;
  price: number;
  previousPrice?: number; // يظهر فقط إذا كان هناك خصم حقيقي معتمد
  internalProductionCost: number; // خاص بلوحة الإدارة فقط ولا يظهر للعميل
  coverImage: string;
  galleryImages: string[];
  coverStyle:
    | "كلاسيكي إسلامي"
    | "Editorial Luxury"
    | "Illustrations للأطفال"
    | "Minimalist"
    | "Cinematic"
    | "Artistic Arabic";
  mainSection: "adults-books" | "kids-books" | "learn-islam";
  categoryId: string;
  categoryName: string;
  ageGroup: string;
  isAdult18Plus?: boolean;
  pagesCount: number;
  fileFormat: string;
  deliveryMethod: string;
  availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)" | "متاح للطلب الرقمي";
  shortDescription: string;
  fullDescription: string;
  tableOfContents: string[];
  verifiedReligiousReference: string;
  isBookOfTheDay?: boolean;
  isFeatured?: boolean;
  isNewArrival?: boolean;
  isBestSeller?: boolean;
}

export const DIGITAL_BOOKS: DigitalBook[] = [
  {
    id: "bk-01",
    slug: "anwar-al-seerah-al-nabawiyah",
    title: "أنوار السيرة النبوية في العهدين المكي والمدني",
    subtitle: "قراءة منهجية موثقة في أحداث السيرة ودروسها التربوية",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice:
      "هذا الكتاب نموذج عرض تجريبي لتوضيح تصميم المتجر وتصنيفاته؛ يتم استبداله ببيانات وملف الكتاب الفعلي لصاحب المتجر من ملف src/data/books.ts.",
    price: 95,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-seerah-noor.webp",
    galleryImages: [
      "/assets/covers/book-seerah-noor.webp",
      "/assets/banners/hero-library.webp",
    ],
    coverStyle: "كلاسيكي إسلامي",
    mainSection: "adults-books",
    categoryId: "ab-seerah",
    categoryName: "السيرة النبوية",
    ageGroup: "للكبار والناشئة (14+ سنة)",
    pagesCount: 210,
    fileFormat: "PDF عالي الدقة (مهيأ للقراءة على الهاتف والتابلت)",
    deliveryMethod: "إرسال إلكتروني عبر واتساب أو البريد بعد تأكيد تحويل فودافون كاش يدويًا",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "عرض متسلسل وميسر لمحطات السيرة النبوية العطرة من المولد الشريف إلى الهجرة وبناء الدولة، مع استنباط الفوائد التربوية والإيمانية.",
    fullDescription:
      "يقدم هذا الإصدار الرقمي جولة معرفية رصينة في رحاب السيرة النبوية الشريفة، مع التركيز على الدروس العملية التي يحتاجها المسلم في حياته اليومية وأسرته، بأسلوب عربي مشرق وموثق من أمهات كتب السيرة الصحيحة.",
    tableOfContents: [
      "الفصل الأول: مكة قبل البعثة وإرهاصات النبوة",
      "الفصل الثاني: نزول الوحي والدعوة السرية والجهرية",
      "الفصل الثالث: دروس الصبر والثبات في المرحلة المكية",
      "الفصل الرابع: الهجرة النبوية وتأسيس المجتمع المدني",
      "الفصل الخامس: أخلاق النبي ﷺ في بيته ومع أصحابه",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿لَّقَدْ كَانَ لَكُمْ فِي رَسُولِ اللَّهِ أُسْوَةٌ حَسَنَةٌ لِّمَن كَانَ يَرْجُو اللَّهَ وَالْيَوْمَ الْآخِرَ وَذَكَرَ اللَّهَ كَثِيرًا﴾ [سورة الأحزاب: الآية 21].",
    isBookOfTheDay: true,
    isFeatured: true,
    isBestSeller: true,
  },
  {
    id: "bk-02",
    slug: "masabeeh-al-duja-sahaba",
    title: "مصابيح الدجى من سير الصحابة الكرام",
    subtitle: "مواقف خالدة في الإيمان والبذل والأخلاق",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 85,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-sahaba-beacon.webp",
    galleryImages: ["/assets/covers/book-sahaba-beacon.webp"],
    coverStyle: "Cinematic",
    mainSection: "adults-books",
    categoryId: "ab-sahaba",
    categoryName: "قصص الصحابة",
    ageGroup: "للكبار والشباب",
    pagesCount: 175,
    fileFormat: "PDF رقمي",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "صفحات مشرقة من تراجم الصحابة رضي الله عنهم تبرز كيف صنع القرآن الكريم جيلاً فريدًا في الأمانة والعدل والرحمة.",
    fullDescription:
      "يتناول الكتاب سير نخبة من الصحابة الكرام بأسلوب قصصي موثق يربط القارئ المعاصر بهمم الرعيل الأول وكيف واجهوا التحديات بالعلم والعمل.",
    tableOfContents: [
      "الصدّيق أبو بكر: يقين الغار وثبات الموقف",
      "الفاروق عمر: العدل الذي أرسى دعائم العمران",
      "ذو النورين عثمان: حياء الملائكة وسخاء البذل",
      "علي بن أبي طالب: باب العلم والشجاعة والحكمة",
      "مصعب بن عمير: أول سفير في الإسلام",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿وَالسَّابِقُونَ الْأَوَّلُونَ مِنَ الْمُهَاجِرِينَ وَالْأَنصَارِ وَالَّذِينَ اتَّبَعُوهُم بِإِحْسَانٍ رَّضِيَ اللَّهُ عَنْهُمْ وَرَضُوا عَنْهُ﴾ [سورة التوبة: الآية 100].",
    isFeatured: true,
    isBestSeller: true,
  },
  {
    id: "bk-03",
    slug: "qudwat-muminat-sahabiyat",
    title: "قدوات مؤمنات: سير نساء بيت النبوة والصحابيات",
    subtitle: "دروس في العلم والصبر وبناء الأجيال",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 80,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-sahabiyat.webp",
    galleryImages: ["/assets/covers/book-sahabiyat.webp"],
    coverStyle: "Editorial Luxury",
    mainSection: "adults-books",
    categoryId: "ab-sahabiyat",
    categoryName: "قصص الصحابيات",
    ageGroup: "للكبار والفتيات",
    pagesCount: 160,
    fileFormat: "PDF رقمي",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "سير عطرة لأمهات المؤمنين والصحابيات العالمات اللواتي أسهمن في حفظ السنة النبوية وبناء الأسرة المسلمة.",
    fullDescription:
      "يستعرض الكتاب نماذج رائدة من حياة خديجة بنت خويلد، وعائشة أم المؤمنين، وفاطمة الزهراء، وأسماء بنت أبي بكر رضي الله عنهن أجمعين.",
    tableOfContents: [
      "خديجة بنت خويلد: السكن الأول والناصر الأمين",
      "عائشة بنت أبي بكر: فقيهة الأمة وراوية الحديث",
      "أسماء ذات النطاقين: شجاعة الموقف وحكمة التربية",
      "أم سلمة: الرأي السديد في صلح الحديبية",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿إِنَّ الْمُسْلِمِينَ وَالْمُسْلِمَاتِ وَالْمُؤْمِنِينَ وَالْمُؤْمِنَاتِ وَالْقَانِتِينَ وَالْقَانِتَاتِ... أَعَدَّ اللَّهُ لَهُم مَّغْفِرَةً وَأَجْرًا عَظِيمًا﴾ [سورة الأحزاب: الآية 35].",
    isNewArrival: true,
  },
  {
    id: "bk-04",
    slug: "mawakib-al-noor-prophets",
    title: "مواكب النور: قصص الأنبياء والمرسلين",
    subtitle: "تأملات قرآنية في دعوة التوحيد وسنن الله في الأمم",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 90,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-prophets-stories.webp",
    galleryImages: ["/assets/covers/book-prophets-stories.webp"],
    coverStyle: "Cinematic",
    mainSection: "adults-books",
    categoryId: "ab-prophets",
    categoryName: "قصص الأنبياء",
    ageGroup: "للكبار والناشئة",
    pagesCount: 230,
    fileFormat: "PDF رقمي",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "دراسة قرآنية في قصص الأنبياء عليهم السلام، مقتصرة على ما صح في الكتاب والسنة دون إسرائيليات غير موثقة.",
    fullDescription:
      "يركز الكتاب على المقاصد التربوية والعقدية من قصص نوح وإبراهيم وموسى وعيسى عليهم السلام كما وردت في آيات القرآن الكريم.",
    tableOfContents: [
      "الحكمة من قصص الأنبياء في القرآن",
      "نوح عليه السلام: الصبر الطويل عبر القرون",
      "إبراهيم خليل الرحمن: الحجة الدامغة والقلب السليم",
      "يوسف الصديق: العفة في البلاء والحكمة في التمكين",
      "موسى كليم الله: التوكل عند البحر ومواجهة الطغيان",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿لَقَدْ كَانَ فِي قَصَصِهِمْ عِبْرَةٌ لِّأُولِي الْأَلْبَابِ ۗ مَا كَانَ حَدِيثًا يُفْتَرَىٰ﴾ [سورة يوسف: الآية 111].",
    isBestSeller: true,
  },
  {
    id: "bk-05",
    slug: "safaa-al-sareerah-tazkiyah",
    title: "صفاء السريرة في تزكية النفس وإصلاح القلوب",
    subtitle: "خطوات عملية لطمأنينة الروح ومعالجة آفات القلب",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 75,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-tazkiyah-qalb.webp",
    galleryImages: ["/assets/covers/book-tazkiyah-qalb.webp"],
    coverStyle: "Minimalist",
    mainSection: "adults-books",
    categoryId: "ab-tazkiyah",
    categoryName: "تزكية النفس",
    ageGroup: "للكبار",
    pagesCount: 150,
    fileFormat: "PDF رقمي",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "دليل هادئ وعملي في محاسبة النفس، الإخلاص، التخلص من الرياء والغفلة، وبناء ورد يومي يحيي القلب.",
    fullDescription:
      "يجمع بين التأصيل الشرعي من القرآن والسنة وأقوال أئمة السلف في أعمال القلوب مثل التوكل والرجاء والخوف والمحبة.",
    tableOfContents: [
      "أهمية القلب في ميزان الشرع",
      "الإخلاص وتحرير النية في الأعمال اليومية",
      "علاج القلق والغفلة بذكر الله",
      "برنامج عملي لمحاسبة النفس وتزكيتها",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿قَدْ أَفْلَحَ مَن زَكَّاهَا * وَقَدْ خَابَ مَن دَسَّاهَا﴾ [سورة الشمس: الآيتان 9-10].",
    isFeatured: true,
  },
  {
    id: "bk-06",
    slug: "al-muyassar-fiqh-ibadat",
    title: "الميسر في فقه العبادات: الطهارة والصلاة والصيام",
    subtitle: "أحكام ميسرة مدعمة بالأدلة الصحيحة والجداول التوضيحية",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 85,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-fiqh-ibadat.webp",
    galleryImages: ["/assets/covers/book-fiqh-ibadat.webp"],
    coverStyle: "كلاسيكي إسلامي",
    mainSection: "adults-books",
    categoryId: "ab-fiqh",
    categoryName: "فقه العبادات",
    ageGroup: "للكبار والناشئة",
    pagesCount: 195,
    fileFormat: "PDF رقمي",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "مرجع ميسر لكل أسرة مسلمة لمعرفة أحكام الطهارة والوضوء والصلاة وسجود السهو والصيام والزكاة بعيدًا عن التعقيد.",
    fullDescription:
      "يرتب المسائل الفقهية في نقاط واضحة وخرائط ذهنية تسهل على القارئ غير المتخصص فهم أحكام عبادته اليومية بدقة.",
    tableOfContents: [
      "كتاب الطهارة: أحكام المياه والوضوء والغسل والتيمم",
      "كتاب الصلاة: الشروط والأركان والواجبات والسنن",
      "أحكام سجود السهو وصلاة المسافر والمريض",
      "كتاب الصيام: المفطرات المعاصرة وآداب الصائم",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿وَأَقِيمُوا الصَّلَاةَ وَآتُوا الزَّكَاةَ وَارْكَعُوا مَعَ الرَّاكِعِينَ﴾ [سورة البقرة: الآية 43].",
  },
  {
    id: "bk-07",
    slug: "usool-al-iman-aqeedah",
    title: "أصول الإيمان: العقيدة الإسلامية للمبتدئين",
    subtitle: "شرح أركان الإيمان الستة بأسلوب واضح وميسر",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 70,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-aqeedah-basics.webp",
    galleryImages: ["/assets/covers/book-aqeedah-basics.webp"],
    coverStyle: "Artistic Arabic",
    mainSection: "learn-islam",
    categoryId: "li-aqeedah-basics",
    categoryName: "أساسيات العقيدة",
    ageGroup: "للكبار والناشئة",
    pagesCount: 140,
    fileFormat: "PDF رقمي",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "مدخل ميسر لتعريف المسلم بربه سبحانه وأسمائه الحسنى، والإيمان بالملائكة والكتب والرسل واليوم الآخر والقدر.",
    fullDescription:
      "يربط العقيدة الإسلامية بأثرها الإيجابي في طمأنينة النفس واستقامة السلوك، مع أسئلة مراجعة في نهاية كل فصل.",
    tableOfContents: [
      "معنى التوحيد وأقسامه وأثره في حياة الإنسان",
      "الإيمان بالملائكة الكرام والكتب المنزلة",
      "الإيمان بالرسل وخاتمهم محمد ﷺ",
      "الإيمان باليوم الآخر وبالقدر خيره وشره",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿آمَنَ الرَّسُولُ بِمَا أُنزِلَ إِلَيْهِ مِن رَّبِّهِ وَالْمُؤْمِنُونَ ۚ كُلٌّ آمَنَ بِاللَّهِ وَمَلَائِكَتِهِ وَكُتُبِهِ وَرُسُلِهِ﴾ [سورة البقرة: الآية 285].",
    isNewArrival: true,
  },
  {
    id: "bk-08",
    slug: "zad-al-dhakireen-adhkar",
    title: "زاد الذاكرين: الأذكار اليومية والأدعية المأثورة",
    subtitle: "مرتبة حسب الأوقات والأحوال من القرآن والسنة الصحيحة",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 60,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-adhkar-hisn.webp",
    galleryImages: ["/assets/covers/book-adhkar-hisn.webp"],
    coverStyle: "Editorial Luxury",
    mainSection: "learn-islam",
    categoryId: "li-daily-adhkar",
    categoryName: "تعليم الأذكار اليومية",
    ageGroup: "للجميع",
    pagesCount: 120,
    fileFormat: "PDF رقمي بتصميم مريح للعين",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "كتيب رقمي أنيق يجمع أذكار الصباح والمساء وأذكار بعد الصلاة والنوم والاستيقاظ مع بيان لطائف معانيها.",
    fullDescription:
      "مصمم بخط عربي واضح وتشكيل كامل ليكون رفيقًا يوميًا على الهاتف المحمول، مع الاقتصار التام على ما ثبت في الصحيحين والسنن المعتمدة.",
    tableOfContents: [
      "فضل الذكر وآدابه",
      "أذكار الصباح والمساء المشروحة",
      "الأذكار المشروعة دبر الصلوات المفروضة",
      "جوامع الدعاء من القرآن الكريم",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿الَّذِينَ آمَنُوا وَتَطْمَئِنُّ قُلُوبُهُم بِذِكْرِ اللَّهِ ۗ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ﴾ [سورة الرعد: الآية 28].",
    isBestSeller: true,
  },
  {
    id: "bk-09",
    slug: "mithaq-al-mawaddah-marriage-18",
    title: "ميثاق المودة والسكينة: فقه الأسرة والحياة الزوجية للبالغين",
    subtitle: "دليل شرعي وتربوي ونفسي للمقبلين على الزواج والمتزوجين (+18)",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 95,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-marriage-sakina.webp",
    galleryImages: ["/assets/covers/book-marriage-sakina.webp"],
    coverStyle: "Editorial Luxury",
    mainSection: "adults-books",
    categoryId: "ab-adults-18",
    categoryName: "قسم كتب +18 للبالغين (تأهيل أسري وزواجي نافع)",
    ageGroup: "للبالغين والمقبلين على الزواج (+18)",
    isAdult18Plus: true,
    pagesCount: 185,
    fileFormat: "PDF رقمي",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "كتاب علمي رصين يعالج فقه الخطبة والزواج، الحقوق والواجبات الزوجية، آداب العشرة الخاصة في ضوء الشرع، وحل الخلافات الأسرية.",
    fullDescription:
      "مخصص للبالغين والمقبلين على الزواج، يتناول الأحكام الشرعية والتربوية للعلاقة الزوجية بلغة علمية راقية ملتزمة بآداب الإسلام.",
    tableOfContents: [
      "مقاصد الزواج في الإسلام ومعايير الاختيار",
      "الحقوق المشتركة وفن الحوار بين الزوجين",
      "الأحكام الفقهية الخاصة بالعشرة الزوجية والطهارة",
      "إدارة الخلافات الأسرية بحكمة ومودة",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُم مَّوَدَّةً وَرَحْمَةً﴾ [سورة الروم: الآية 21].",
  },
  {
    id: "bk-10",
    slug: "ghars-al-fitrah-parenting",
    title: "غرس الفطرة: التربية الإسلامية للأبناء في العصر الرقمي",
    subtitle: "توجيهات نبوية وأساليب تربوية معاصرة لحماية هوية الطفل",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 85,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-parenting-fitrah.webp",
    galleryImages: ["/assets/covers/book-parenting-fitrah.webp"],
    coverStyle: "Artistic Arabic",
    mainSection: "adults-books",
    categoryId: "ab-parenting",
    categoryName: "كتب تربية الأبناء",
    ageGroup: "للآباء والأمهات والمربين",
    pagesCount: 170,
    fileFormat: "PDF رقمي",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "دليل عملي يعين الوالدين على غرس حب الله والصلاة والأخلاق في نفوس الأبناء، والتعامل الحكيم مع الشاشات والألعاب الإلكترونية.",
    fullDescription:
      "يقدم خططًا تربوية مقسمة حسب المراحل العمرية من الطفولة المبكرة حتى المراهقة، مع أنشطة حوارية أسرية.",
    tableOfContents: [
      "القدوة الحسنة في البيت المسلم",
      "كيف نجعل الإيمان والصلاة محبوبين لدى الطفل؟",
      "ضوابط التعامل مع الأجهزة الذكية ووسائل التواصل",
      "بناء الثقة والمسؤولية لدى الناشئة",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿يَا أَيُّهَا الَّذِينَ آمَنُوا قُوا أَنفُسَكُمْ وَأَهْلِيكُمْ نَارًا﴾ [سورة التحريم: الآية 6].",
    isFeatured: true,
  },
  {
    id: "bk-11",
    slug: "hikayat-al-anbiya-kids",
    title: "حكايات الأنبياء للصغار: سفينة نوح وبستان إبراهيم",
    subtitle: "قصص مصورة مشوقة لغرس الإيمان وتوحيد الله في قلوب الأطفال",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 65,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-kids-prophets.webp",
    galleryImages: [
      "/assets/covers/book-kids-prophets.webp",
      "/assets/banners/kids-corner.webp",
    ],
    coverStyle: "Illustrations للأطفال",
    mainSection: "kids-books",
    categoryId: "kb-prophets",
    categoryName: "قصص الأنبياء للأطفال",
    ageGroup: "للأطفال (6 - 12 سنة)",
    pagesCount: 64,
    fileFormat: "PDF ملون عالي الجودة",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "قصص مصورة بلغة عربية سهلة ومحببة للصغار، مع مراعاة عدم تجسيد الأنبياء عليهم السلام بالرسوم التزامًا بالضوابط الشرعية.",
    fullDescription:
      "يعتمد الكتاب على الرسوم الطبيعية والمشاهد المعبرة دون تصوير ذوات الأنبياء عليهم السلام، مع خلاصة تربوية وسؤال تفاعلي بعد كل قصة.",
    tableOfContents: [
      "قصة سفينة نوح عليه السلام والنجاة العظيمة",
      "إبراهيم عليه السلام يتأمل النجوم والكواكب",
      "حوت يونس عليه السلام ودعاء التسبيح",
      "ماذا نتعلم من صبر الأنبياء؟",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿وَكَذَٰلِكَ نُرِي إِبْرَاهِيمَ مَلَكُوتَ السَّمَاوَاتِ وَالْأَرْضِ وَلِيَكُونَ مِنَ الْمُوقِنِينَ﴾ [سورة الأنعام: الآية 75].",
    isFeatured: true,
    isBestSeller: true,
  },
  {
    id: "bk-12",
    slug: "rihlati-maa-al-wudu-wa-al-salah",
    title: "رحلتي مع الوضوء والصلاة خطوة بخطوة بالصور",
    subtitle: "دليل مصور ومبسط لتعليم الأطفال والناشئة الطهارة والصلاة",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 60,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-kids-wudu-salah.webp",
    galleryImages: [
      "/assets/covers/book-kids-wudu-salah.webp",
      "/assets/banners/learn-islam.webp",
    ],
    coverStyle: "Illustrations للأطفال",
    mainSection: "learn-islam",
    categoryId: "li-wudu-steps",
    categoryName: "تعلم الوضوء بالصور خطوة بخطوة",
    ageGroup: "للأطفال والناشئة (5 - 13 سنة)",
    pagesCount: 56,
    fileFormat: "PDF مصور + جدول متابعة الصلاة قابل للطباعة",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "يعلم الطفل خطوات الوضوء بالترتيب الصحيح، وأعمال الصلاة وعدد ركعاتها وما يقال في الركوع والسجود والتشهد باللوحات الإرشادية.",
    fullDescription:
      "مقسم إلى بطاقات بصرية مرقمة تسهل على الطفل التطبيق العملي، ومرفق بجدول تحفيزي أسبوعي لمتابعة الصلوات الخمس.",
    tableOfContents: [
      "كيف أتوضأ خطوة بخطوة؟ (من النية والبسملة إلى غسل الرجلين)",
      "الصلوات الخمس وعدد ركعاتها",
      "صفة الصلاة بالخطوات المصورة وأذكار الركوع والسجود",
      "جدول نجم الصلاة الأسبوعي للطباعة",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا قُمْتُمْ إِلَى الصَّلَاةِ فَاغْسِلُوا وُجُوهَكُمْ وَأَيْدِيَكُمْ إِلَى الْمَرَافِقِ وَامْسَحُوا بِرُءُوسِكُمْ وَأَرْجُلَكُمْ إِلَى الْكَعْبَيْنِ﴾ [سورة المائدة: الآية 6].",
    isBestSeller: true,
    isFeatured: true,
  },
  {
    id: "bk-13",
    slug: "hamasat-al-nujoom-bedtime-kids",
    title: "همسات النجوم قبل النوم: قصص تربوية وأذكار المساء للأطفال",
    subtitle: "حكايات دافئة تزرع الصدق والأمانة وبر الوالدين والتعاون",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 55,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-kids-bedtime.webp",
    galleryImages: ["/assets/covers/book-kids-bedtime.webp"],
    coverStyle: "Illustrations للأطفال",
    mainSection: "kids-books",
    categoryId: "kb-bedtime",
    categoryName: "قصص قبل النوم",
    ageGroup: "للأطفال (4 - 10 سنوات)",
    pagesCount: 48,
    fileFormat: "PDF ملون",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "سبع قصص مسائية هادئة، لكل ليلة قصة تغرس خلقًا كريمًا وتختتم بآداب النوم والذكر النبوي الصحيح.",
    fullDescription:
      "مصمم ليقرأه الوالدان للطفل قبل النوم في 10 دقائق، بألوان دافئة مريحة ولغة عربية فصحى قريبة من خيال الطفل.",
    tableOfContents: [
      "الليلة الأولى: تاجر الصدق الصغير",
      "الليلة الثانية: هدية لأمي وأبي (بر الوالدين)",
      "الليلة الثالثة: خلية النحل المتعاونة",
      "الليلة الرابعة: أمانة الصندوق الخشبي",
      "آداب النوم وأذكاره للصغار",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿وَقَضَىٰ رَبُّكَ أَلَّا تَعْبُدُوا إِلَّا إِيَّاهُ وَبِالْوَالِدَيْنِ إِحْسَانًا﴾ [سورة الإسراء: الآية 23].",
    isNewArrival: true,
  },
  {
    id: "bk-14",
    slug: "fanoos-shahr-al-khayr-ramadan-kids",
    title: "فانوس شهر الخير: يوميات طفل مسلم في رمضان",
    subtitle: "قصص وأنشطة تفاعلية وجدول عبادات مصور لثلاثين يومًا",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 65,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-kids-ramadan.webp",
    galleryImages: ["/assets/covers/book-kids-ramadan.webp"],
    coverStyle: "Illustrations للأطفال",
    mainSection: "kids-books",
    categoryId: "kb-ramadan",
    categoryName: "قصص رمضان",
    ageGroup: "للأطفال (6 - 13 سنة)",
    pagesCount: 68,
    fileFormat: "PDF تفاعلي قابل للطباعة",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "رحلة يومية طوال شهر رمضان المبارك تجمع بين القصة القصيرة، آية اليوم، خلق اليوم، ونشاط الصدقة والإحسان.",
    fullDescription:
      "يحول أيام شهر رمضان إلى تجربة تربوية مبهجة للطفل، مع شهادة تقدير قابلة للطباعة عند إتمام أنشطة الشهر.",
    tableOfContents: [
      "أهلاً هلال رمضان: لماذا نصوم؟",
      "بركة السحور وفرحة الإفطار",
      "ليلة القدر خير من ألف شهر",
      "فرحة عيد الفطر وزكاة الفطر",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿شَهْرُ رَمَضَانَ الَّذِي أُنزِلَ فِيهِ الْقُرْآنُ هُدًى لِّلنَّاسِ وَبَيِّنَاتٍ مِّنَ الْهُدَىٰ وَالْفُرْقَانِ﴾ [سورة البقرة: الآية 185].",
  },
  {
    id: "bk-15",
    slug: "alwan-al-adab-coloring-book",
    title: "ألوان الآداب الإسلامية: كتاب تلوين وأنشطة تعليمية هادفة",
    subtitle: "تعلم البسملة والحمد والآداب اليومية بالرسم والتلوين",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 45,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-kids-coloring.webp",
    galleryImages: ["/assets/covers/book-kids-coloring.webp"],
    coverStyle: "Illustrations للأطفال",
    mainSection: "kids-books",
    categoryId: "kb-coloring",
    categoryName: "كتب التلوين الإسلامية",
    ageGroup: "للأطفال (3 - 9 سنوات)",
    pagesCount: 40,
    fileFormat: "PDF جاهز للطباعة المنزلية A4",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "40 لوحة تلوين وتمارين توصيل ومتاهات تعليمية تغرس آداب الطعام والسلام والنظافة وإماطة الأذى عن الطريق.",
    fullDescription:
      "يمكن للأسرة طباعته أكثر من مرة لأطفال البيت، مع خطوط واضحة ومناسبة للألوان الخشبية والشمعية.",
    tableOfContents: [
      "لوحات بسم الله والحمد لله",
      "آداب المسجد والقرآن",
      "العناية بالبيئة والرفق بالحيوان",
      "متاهات وألغاز ذكاء تربوية",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿وَقُولُوا لِلنَّاسِ حُسْنًا﴾ [سورة البقرة: الآية 83].",
    isNewArrival: true,
  },
  {
    id: "bk-16",
    slug: "mafateeh-al-tadabbur-quran",
    title: "مفاتيح التدبر: وقفات إيمانية مع آيات الكتاب الحكيم",
    subtitle: "كيف نعيش بالقرآن ونتدبر رسائله في حياتنا اليومية",
    authorLabel: "نموذج عرض تجريبي — مخصص لمؤلفات صاحب متجر رُقّ وقرطاس",
    isDemoSample: true,
    demoNotice: "نموذج عرض تجريبي قابل للاستبدال المباشر بمؤلفات صاحب المتجر.",
    price: 85,
    internalProductionCost: 0,
    coverImage: "/assets/covers/book-tadabbur-quran.webp",
    galleryImages: ["/assets/covers/book-tadabbur-quran.webp"],
    coverStyle: "كلاسيكي إسلامي",
    mainSection: "adults-books",
    categoryId: "ab-tadabbur",
    categoryName: "كتب التفكر والتدبر",
    ageGroup: "للكبار والشباب",
    pagesCount: 180,
    fileFormat: "PDF رقمي",
    deliveryMethod: "تسليم رقمي بعد التحقق اليدوي من الدفع",
    availabilityStatus: "نموذج عرض تجريبي (جاهز للاستبدال بكتاب المؤلف)",
    shortDescription:
      "منهج عملي يساعد القارئ على الانتقال من مجرد تلاوة الحروف إلى فهم المعاني والعمل بآيات القرآن الكريم.",
    fullDescription:
      "يتضمن قواعد التدبر العشر ونماذج تطبيقية من سور الفاتحة والكهف والملك وقصار السور، بالاعتماد على التفاسير الموثوقة.",
    tableOfContents: [
      "الفرق بين القراءة العابرة والقراءة المتدبرة",
      "عشر وسائل عملية للخشوع والتدبر",
      "وقفات تدبرية مع سورة الفاتحة",
      "كيف تكتب فوائدك القرآنية في كناشة التدبر؟",
    ],
    verifiedReligiousReference:
      "قال الله تعالى: ﴿كِتَابٌ أَنزَلْنَاهُ إِلَيْكَ مُبَارَكٌ لِّيَدَّبَّرُوا آيَاتِهِ وَلِيَتَذَكَّرَ أُولُو الْأَلْبَابِ﴾ [سورة ص: الآية 29].",
    isFeatured: true,
  },
];
