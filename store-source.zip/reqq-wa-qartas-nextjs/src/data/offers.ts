export interface BookBundleOffer {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  seasonTag: string;
  bookIds: string[];
  bannerImage: string;
  description: string;
  whatsappInquiryLabel: string;
}

export const BOOK_BUNDLE_OFFERS: BookBundleOffer[] = [
  {
    id: "bnd-family-library",
    slug: "complete-muslim-family-library-bundle",
    title: "مجموعة مكتبة الأسرة المسلمة المتكاملة",
    subtitle: "4 كتب رقمية تجمع بين السيرة النبوية وفقه العبادات وتربية الأبناء والأذكار",
    seasonTag: "عرض مجموعات الكتب",
    bookIds: ["bk-01", "bk-06", "bk-10", "bk-08"],
    bannerImage: "/assets/banners/hero-library.webp",
    description:
      "باقة تأسيسية لكل بيت مسلم تجمع أهم الكتب الرقمية في السيرة وفقه العبادات اليومية وغرس الفطرة في الأبناء وأذكار اليوم والليلة.",
    whatsappInquiryLabel: "استفسر عن عرض مجموعة الأسرة المسلمة عبر واتساب",
  },
  {
    id: "bnd-little-muslim",
    slug: "little-muslim-educational-bundle",
    title: "مجموعة مكتبة الطفل المسلم (قصص + صلاة + تلوين)",
    subtitle: "4 إصدارات مصورة وتفاعلية للأطفال من 4 إلى 12 سنة",
    seasonTag: "باقة الطفل التربوية",
    bookIds: ["bk-11", "bk-12", "bk-13", "bk-15"],
    bannerImage: "/assets/banners/kids-corner.webp",
    description:
      "مجموعة متكاملة تغرس محبة الأنبياء وتعلم الوضوء والصلاة بالصور وتقدم قصصًا مسائية هادئة مع دفتر تلوين الآداب الإسلامية.",
    whatsappInquiryLabel: "اطلب عرض مجموعة الطفل المسلم عبر واتساب",
  },
  {
    id: "bnd-ramadan-spiritual",
    slug: "ramadan-and-tazkiyah-seasonal-bundle",
    title: "مجموعة تزكية القلوب ومواسم الخيرات (رمضان والتدبر)",
    subtitle: "3 كتب رقمية في تدبر القرآن وتزكية النفس ويوميات رمضان للصغار",
    seasonTag: "عرض موسمي قابل للتعديل",
    bookIds: ["bk-05", "bk-16", "bk-14"],
    bannerImage: "/assets/banners/learn-islam.webp",
    description:
      "باقة إيمانية للأسرة تجمع بين مفاتيح تدبر القرآن وصفاء السريرة مع يوميات فانوس شهر الخير للأطفال.",
    whatsappInquiryLabel: "اسألنا عن عرض مجموعة مواسم الخيرات عبر واتساب",
  },
];
