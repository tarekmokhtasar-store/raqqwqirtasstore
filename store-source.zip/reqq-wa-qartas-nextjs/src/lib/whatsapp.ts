import { STORE_SETTINGS } from "@/data/store-settings";
import { DigitalBook } from "@/data/books";
import { PhysicalProduct } from "@/data/products";

export interface CartItem {
  id: string;
  itemType: "book" | "product";
  title: string;
  price: number | null;
  quantity: number;
  image: string;
  slug: string;
  selectedColor?: string;
  selectedSize?: string;
  selectedOption?: string;
}

export function buildWhatsAppLink(message: string): string {
  return `https://wa.me/${STORE_SETTINGS.whatsappIntl}?text=${encodeURIComponent(message)}`;
}

export function buildBookOrderMessage(
  book: DigitalBook,
  quantity: number,
  originUrl: string = "https://reqq-wa-qartas.vercel.app"
): string {
  const bookUrl = `${originUrl}/books/${book.slug}`;
  return `السلام عليكم، أريد طلب كتاب من متجر رُقّ وقرطاس:
اسم الكتاب: ${book.title}
السعر: ${book.price} ${STORE_SETTINGS.currencySymbol}
الكمية: ${quantity}
رابط الكتاب: ${bookUrl}
أرجو تأكيد طريقة الدفع والاستلام.`;
}

export function buildProductOrderMessage(
  product: PhysicalProduct,
  quantity: number,
  colorOrSize: string,
  governorate: string,
  address: string,
  phone: string
): string {
  const priceText =
    product.priceVerified && product.customerFinalPrice !== null
      ? `${product.customerFinalPrice} ${STORE_SETTINGS.currencySymbol}`
      : "يُؤكد السعر النهائي قبل اعتماد الطلب";
  return `السلام عليكم، أريد طلب منتج من متجر رُقّ وقرطاس:
اسم المنتج: ${product.name}
السعر: ${priceText}
الكمية: ${quantity}
اللون/المقاس: ${colorOrSize || "القياسي"}
المحافظة: ${governorate || "لم يحدد بعد"}
العنوان: ${address || "سيتم تأكيده"}
رقم الهاتف: ${phone || "نفس رقم الواتساب"}
يرجى تأكيد التوفر وتكلفة الشحن.`;
}

export function buildCartWhatsAppMessage(
  items: CartItem[],
  customerInfo: {
    name?: string;
    phone?: string;
    governorate?: string;
    address?: string;
    transferRef?: string;
    notes?: string;
  }
): string {
  const bookItems = items.filter((i) => i.itemType === "book");
  const productItems = items.filter((i) => i.itemType === "product");
  const totalBooksCount = bookItems.reduce((acc, item) => acc + item.quantity, 0);
  const confirmedBooksSubtotal = bookItems.reduce(
    (acc, item) => acc + (item.price || 0) * item.quantity,
    0
  );

  let discountAmount = 0;
  if (
    STORE_SETTINGS.bookBundleRuleActive &&
    totalBooksCount >= 3 &&
    STORE_SETTINGS.bookBundleDiscountPercent > 0
  ) {
    discountAmount = Math.round(
      (confirmedBooksSubtotal * STORE_SETTINGS.bookBundleDiscountPercent) / 100
    );
  }
  const finalBooksTotal = confirmedBooksSubtotal - discountAmount;

  let lines: string[] = [
    "السلام عليكم، أريد إتمام طلب سلة تسوق من متجر رُقّ وقرطاس:",
    "━━━━━━━━━━━━━━",
  ];

  if (bookItems.length > 0) {
    lines.push("📚 الكتب الرقمية المختارة:");
    bookItems.forEach((b, idx) => {
      lines.push(
        `${idx + 1}. ${b.title} | الكمية: ${b.quantity} | السعر: ${(b.price || 0) * b.quantity} ${STORE_SETTINGS.currencySymbol}`
      );
    });
    if (totalBooksCount > 2) {
      lines.push(`✨ ملاحظة المجموعات: لدي ${totalBooksCount} كتب في السلة وأود الاستفادة من عروض مجموعات الكتب.`);
    }
  }

  if (productItems.length > 0) {
    lines.push("📦 المنتجات المادية المختارة:");
    productItems.forEach((p, idx) => {
      const priceLabel =
        p.price !== null
          ? `${p.price * p.quantity} ${STORE_SETTINGS.currencySymbol}`
          : "يُؤكد السعر اللحظي والشحن";
      const specs = [p.selectedColor, p.selectedSize, p.selectedOption]
        .filter(Boolean)
        .join(" - ");
      lines.push(
        `${idx + 1}. ${p.title} (${specs || "خيار قياسي"}) | الكمية: ${p.quantity} | السعر: ${priceLabel}`
      );
    });
  }

  lines.push("━━━━━━━━━━━━━━");
  lines.push(`💰 إجمالي الكتب الرقمية المؤكد: ${finalBooksTotal} ${STORE_SETTINGS.currencySymbol}`);
  if (discountAmount > 0) {
    lines.push(`🎁 الخصم المعتمد للمجموعة: ${discountAmount} ${STORE_SETTINGS.currencySymbol}`);
  }
  if (productItems.length > 0) {
    lines.push("🚚 المنتجات المادية: يرجى تأكيد التوفر اللحظي وتكلفة الشحن للمحافظة.");
  }

  if (customerInfo.name) lines.push(`👤 الاسم: ${customerInfo.name}`);
  if (customerInfo.phone) lines.push(`📱 الهاتف: ${customerInfo.phone}`);
  if (customerInfo.governorate) lines.push(`📍 المحافظة: ${customerInfo.governorate}`);
  if (customerInfo.address) lines.push(`🏠 العنوان التفصيلي: ${customerInfo.address}`);
  if (customerInfo.transferRef) {
    lines.push(`💳 مرجع تحويل فودافون كاش: ${customerInfo.transferRef}`);
  }
  if (customerInfo.notes) lines.push(`📝 ملاحظات: ${customerInfo.notes}`);

  lines.push("أرجو مراجعة الطلب وتأكيد الدفع والاستلام.");
  return lines.join("\n");
}
