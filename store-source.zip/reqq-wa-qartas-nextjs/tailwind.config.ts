import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        emerald: {
          950: "#06231B",
          900: "#0B3B2E",
          800: "#125241",
          700: "#1B6B55",
        },
        gold: {
          300: "#E8CF8C",
          400: "#D4AF37",
          500: "#C5A059",
          600: "#9A7B38",
          700: "#785D26",
        },
        parchment: {
          50: "#FBF8F3",
          100: "#F5EFE6",
          200: "#EAE0D0",
          300: "#D8C8B0",
        },
        ink: {
          900: "#1F1610",
          800: "#2C1E14",
          700: "#4A3525",
          600: "#6B4F38",
        }
      },
      fontFamily: {
        cairo: ["Cairo", "sans-serif"],
        tajawal: ["Tajawal", "sans-serif"],
      },
    },
  },
  plugins: [],
};
export default config;
